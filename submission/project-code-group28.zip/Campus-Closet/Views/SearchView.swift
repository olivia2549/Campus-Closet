//
//  SearchView.swift
//  Campus-Closet
//
//  Created by Olivia Logan on 10/22/22.
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        Text("Search!")
    }
}
