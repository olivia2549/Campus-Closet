//
//  AppDelegate.swift
//  Campus-Closet
//
//  Created by Hilly Yehoshua on 11/10/22.
//
import Firebase
//import FirebaseMessaging
import UserNotificationsUI
import UIKit
import Foundation

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    func application( application: UIApplication, didFinishLaunchingWithOptions launchOpetions: [UIApplication.LaunchOptionsKey: Any]?)
}
